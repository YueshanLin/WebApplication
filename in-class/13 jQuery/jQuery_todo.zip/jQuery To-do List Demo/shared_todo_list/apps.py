from __future__ import unicode_literals

from django.apps import AppConfig


class SharedTodoListConfig(AppConfig):
    name = 'shared_todo_list'
